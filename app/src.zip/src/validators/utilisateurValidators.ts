import { Request, Response, NextFunction } from 'express'; 
import { createUser } from '../controllers/utilisateurController.js'
import { body, validationResult } from 'express-validator'; 

export function validateForm(req: Request, res: Response, next: NextFunction): void {

    body('nom').isString().notEmpty(), 
    body('email').isEmail(), 
    (req: Request, res: Response) => { 
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
        }
        next();
    }
}