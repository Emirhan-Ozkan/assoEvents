import { Request, Response } from 'express'; 
import { users, Utilisateur } from '../models/utilisateur.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { JSDOM } from "jsdom";


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function listerUtilisateurs(req: Request, res: Response): Response {
    return res.json(users);
}

export function trouverUtilisateurParId(req: Request, res: Response): Response {
    if (typeof req.params.id !== 'string') {
        return res.status(400).json({ error: 'ID invalide' });
    }
    const ID: number = parseInt(req.params.id);
    const utilisateur = users.find((user) => user.id === ID);
    if (!utilisateur) {
        return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }
    return res.json(utilisateur);
}

export function showUsers(req: Request, res: Response): Response {
    // prendre le fichier html
    const vue = path.join(__dirname, '../views/users.html');
    const html = fs.readFileSync(vue, 'utf-8');

    // le transformer d'un string en 'document'
    const dom = new JSDOM(html);
    const document = dom.window.document;
    const usersElement = document.querySelector("#users");

    // la manipuler
    if (usersElement) {
        usersElement.textContent = JSON.stringify(users);
    }

    // la transformer en string pour l'envoyer
    const s = dom.serialize();

    // l'envoyer
    return res.send(s);
}

export function createUser(req: Request, res: Response): void {
    const { nom, email } = req.body;

    console.log('Nouvel utilisateur reçu :', nom, email);

    const u: Utilisateur = {id: 0, nom: "", email: ""};

    u.nom = nom;
    u.email = email;

    let x: number;
    do {
        u.id = Math.floor(Math.random() * 1000000 + 1);
        x = users.filter(user => user.id === u.id).length;
    } while (x != 0)

    users.push(u);
    
    res.status(201).json({ message: 'Utilisateur créé', user: { nom, email } });
}
