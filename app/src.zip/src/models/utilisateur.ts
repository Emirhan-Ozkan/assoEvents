export class Utilisateur {
    constructor(
        public id: number,
        public nom: string,
        public email: string) 
    {}
}

export let users: Utilisateur[] = [
    {
        id: 1,
        nom: "Tom",
        email: "tom@email.com"
    },
    {
        id: 2,
        nom: "Marc",
        email: "marc@email.com"
    },
    {
        id: 3,
        nom: "Anna",
        email: "anna@email.com"
    }

]